# rss-downloader

This thingy should download a bunch of rss feeds and then put them somewhere.
